#define IDD_LOGIN                       101
#define IDC_LOGIN_PASSWORD              1000
#define IDC_LOGIN_PROMPT                1001
